package org.xmind.core.internal;

import org.xmind.core.ISheetSettings;

/**
 * @author Jason Wong
 * @since 3.6.50
 */
public abstract class SheetSettings extends AbstractWorkbookComponent
        implements ISheetSettings {

}
