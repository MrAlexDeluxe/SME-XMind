package org.xmind.core.internal;

import org.xmind.core.IRevisionRepository;

public abstract class RevisionRepository extends AbstractWorkbookComponent
        implements IRevisionRepository {

}
