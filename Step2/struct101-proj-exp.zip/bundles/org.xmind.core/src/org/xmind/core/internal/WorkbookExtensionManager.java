package org.xmind.core.internal;

import org.xmind.core.IWorkbookExtensionManager;

/**
 * @author Jason Wong
 */
public abstract class WorkbookExtensionManager
        implements IWorkbookExtensionManager {

}
